package com.kelfan.textfiler;

public interface ITextParser {
}
